Rainy weather camera dataset
