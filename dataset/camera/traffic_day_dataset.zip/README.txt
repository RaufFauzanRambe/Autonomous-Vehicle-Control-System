Daytime traffic camera dataset
