Nighttime traffic camera dataset
